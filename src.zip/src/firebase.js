// src/firebase.js
import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';

const firebaseConfig = {
  apiKey: "AIzaSyCLXVKr88D9o8FCD4Npkv4ShTVXP9LlPt8",
  authDomain: "voting-app-1304b.firebaseapp.com",
  databaseURL: "https://voting-app-membervotes.asia-southeast1.firebasedatabase.app/",
  projectId: "voting-app-1304b",
  storageBucket: "voting-app-1304b.firebasestorage.app",
  messagingSenderId: "323127752443",
  appId: "1:323127752443:web:a7d2435c56ed361ae8e25e",
  measurementId: "G-1LLZBV0FWX"
};

const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

export { database };
