import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { database } from '../firebase'; // Import the initialized database

const district1MemberCount = 10;
const district2MemberCount = 11;

const MemberDevice = () => {
    const [votes, setVotes] = useState({});
    const [selectedDistrict, setSelectedDistrict] = useState('District 1');
    const [isClicking, setIsClicking] = useState({});
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const memberVotesRef = ref(database, `municipal_member_votes/${selectedDistrict.toLowerCase().replace(/\s+/g, '')}`);
        const unsubscribe = onValue(memberVotesRef, (snapshot) => {
            const data = snapshot.val();
            if (data) {
                setVotes(data);
            } else {
                const initialVotes = {};
                for (let i = 1; i <= (selectedDistrict === 'District 1' ? district1MemberCount : district2MemberCount); i++) {
                    initialVotes[`Member${i}`] = 0;
                }
                update(memberVotesRef, initialVotes)
                    .then(() => {
                        setVotes(initialVotes);
                    })
                    .catch((err) => console.error("Error initializing votes", err));
            }
            setLoading(false);
        });

        return () => unsubscribe();
    }, [selectedDistrict]);

    const handleVillageChange = (event) => {
        setSelectedDistrict(event.target.value);
        setIsClicking({});
        setLoading(true);
    };

    const handleVote = useCallback((memberIdentifier: string) => {
        if (selectedDistrict) {
            const voteRef = ref(database, `municipal_member_votes/${selectedDistrict.toLowerCase().replace(/\s+/g, '')}/${memberIdentifier}`);
            runTransaction(voteRef, (currentVotes) => {
                if (currentVotes === null) {
                    return 1;
                }
                return currentVotes + 1;
            }).then((transactionResult) => {
                if (transactionResult.committed) {
                    setVotes(prevVotes => ({
                        ...prevVotes,
                        [memberIdentifier]: transactionResult.snapshot.val() || 0
                    }));
                }
            }).catch((error) => {
                console.error("Error running transaction:", error);
            });
            setIsClicking(prev => ({ ...prev, [memberIdentifier]: true }));
            setTimeout(() => setIsClicking(prev => ({ ...prev, [memberIdentifier]: false })), 100);
        } else {
            alert('Please select a district.');
        }
    }, [selectedDistrict]);

    const memberCount = selectedDistrict === 'District 1' ? district1MemberCount : district2MemberCount;
    const memberNames = Array.from({ length: memberCount }, (_, i) => `Member${i + 1}`);

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-black p-4 sm:p-8">
            <div className="max-w-4xl mx-auto space-y-6">
                <div className="text-center space-y-2">
                    <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
                        MEMBER VOTE
                    </h1>
                    <p className="text-lg text-gray-400">Counting System</p>
                </div>

                <div className="flex justify-center">
                    <div className="w-full sm:w-auto">
                        <label htmlFor="district" className="block text-sm font-medium text-gray-300 mb-2">
                            Select District:
                        </label>
                        <select
                            id="district"
                            value={selectedDistrict}
                            onChange={handleVillageChange}
                            className="w-full sm:w-64 px-4 py-2 rounded-md border border-gray-700 bg-gray-800 text-white shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        >
                            <option value="District 1">District 1</option>
                            <option value="District 2">District 2</option>
                        </select>
                    </div>
                </div>

                {loading ? (
                    <div className="text-center text-gray-400">Loading...</div>
                ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
                        <AnimatePresence>
                            {memberNames.map((memberName) => {
                                const voteCount = votes[memberName] || 0;
                                return (
                                    <motion.div
                                        key={memberName}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0, y: -20 }}
                                        transition={{ duration: 0.2 }}
                                    >
                                        <Card
                                            className={cn(
                                                "bg-gray-800 border border-gray-700 shadow-lg",
                                                "transition-all duration-300",
                                                "hover:bg-gray-700/50 hover:scale-[1.02]",
                                            )}
                                        >
                                            <CardHeader>
                                                <CardTitle className="text-lg font-semibold text-white">{memberName}</CardTitle>
                                            </CardHeader>
                                            <CardContent className="space-y-4">
                                                <div className="flex items-center justify-between">
                                                    <Button
                                                        onClick={() => handleVote(memberName)}
                                                        disabled={isClicking[memberName]}
                                                        className={cn(
                                                            "w-full bg-gradient-to-r from-green-500 to-green-600 text-white font-bold py-2 px-4 rounded-md shadow-md transition-all duration-200 hover:from-green-400 hover:to-green-500 hover:scale-105 active:scale-95",
                                                            isClicking[memberName] && "scale-95 opacity-70",
                                                        )}
                                                    >
                                                        Vote
                                                    </Button>
                                                </div>
                                                <div className="text-center">
                                                    <p className="text-xl font-bold text-green-300">{voteCount} Votes</p>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </motion.div>
                                );
                            })}
                        </AnimatePresence>
                    </div>
                )}
            </div>
        </div>
    );
};

export default MemberDevice;