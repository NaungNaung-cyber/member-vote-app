import React from 'react';
import MemberDevice from './MemberDevice';
import MemberResult from './MemberResult';
import './App.css'; // You might need to create this file for global styles

function App() {
    return (
        <div className="App">
            <header className="App-header">
                <h1 className="text-3xl font-bold underline text-white">Voting App</h1>
            </header>
            <main>
                <MemberDevice />
                <MemberResult />
            </main>
        </div>
    );
}

export default App;